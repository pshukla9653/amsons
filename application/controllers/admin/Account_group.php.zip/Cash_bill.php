<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cash_bill extends CI_Controller
{ 
    public  $cl="6";
	function __construct()
	{		
		parent::__construct();
	  
		if(!isset($this->session->userdata['admin'])){
			redirect('admin/login');
		}
		if($this->session->userdata('access')->ads==0)
		{
			redirect('admin/dashboard');
		}
		$this->load->library("pagination");
	}
	
	public function index()
	{
		$config = array();
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul><!--pagination-->';
		
		$config['first_link'] = '&laquo; First';
		$config['first_tag_open'] = '<li class="prev page">';
		$config['first_tag_close'] = '</li>';

		$config['last_link'] = 'Last &raquo;';
		$config['last_tag_open'] = '<li class="next page">';
		$config['last_tag_close'] = '</li>'; 

		$config['next_link'] = 'Next &rarr;';
		$config['next_tag_open'] = '<li class="next page">';
		$config['next_tag_close'] = '</li>';

		$config['prev_link'] = '&larr; Previous';
		$config['prev_tag_open'] = '<li class="prev page">';
		$config['prev_tag_close'] = '</li>';

		$config['cur_tag_open'] = '<li class="active"><a href="">';
		$config['cur_tag_close'] = '</a></li>';

		$config['num_tag_open'] = '<li class="page">';
		$config['num_tag_close'] = '</li>';
		if(!empty($this->input->post('name')))
		{
			$name=$this->input->post('name');
			$data['name']= $name;
			$query = $this->db->query("SELECT tbl_bill_cash.*, c.client_name FROM tbl_bill_cash
			INNER JOIN tbl_bill ON tbl_bill_cash.tb_bill_id=tbl_bill.id 
			INNER JOIN tbl_client c ON c.id=tbl_bill.client_id WHERE (tbl_bill.work_year='".$_SESSION['work_year']."')AND( tbl_bill.id LIKE '%".$name."%'  OR c.client_name LIKE '%".$name."%' and tbl_bill.type=''");
			$config["base_url"] = base_url() . "admin/cash_bill/index";
			$config["total_rows"] = $query->num_rows();
			$config["per_page"] = 20;
			$config["uri_segment"] = 4;
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
			$data['ad_prices']= $query->result();
		}
		else
		{
			$query = $this->db->query("SELECT tbl_reciept.* FROM `tbl_reciept`");
		
			$config["base_url"] = base_url(). "admin/cash_bill/index";
			$config["total_rows"] = $query->num_rows();
			$config["per_page"] = 20;
			$config["uri_segment"] = 4;
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
				$query = $this->db->query("SELECT tbl_reciept.* FROM `tbl_reciept`");
		
		
			$data['bills']= $query->result();
		}		
		$data['per_page'] = 20;
		$data['offset'] = $page ;
		$data["total_rows"] = $config["total_rows"];
		
		$this->load->view('admin/header');
		$this->load->view('admin/cash_bill_list', $data);
		$this->load->view('admin/footer');
	}
	
	
	
	public function report()
	{
		$config = array();
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul><!--pagination-->';
		
		$config['first_link'] = '&laquo; First';
		$config['first_tag_open'] = '<li class="prev page">';
		$config['first_tag_close'] = '</li>';

		$config['last_link'] = 'Last &raquo;';
		$config['last_tag_open'] = '<li class="next page">';
		$config['last_tag_close'] = '</li>'; 

		$config['next_link'] = 'Next &rarr;';
		$config['next_tag_open'] = '<li class="next page">';
		$config['next_tag_close'] = '</li>';

		$config['prev_link'] = '&larr; Previous';
		$config['prev_tag_open'] = '<li class="prev page">';
		$config['prev_tag_close'] = '</li>';

		$config['cur_tag_open'] = '<li class="active"><a href="">';
		$config['cur_tag_close'] = '</a></li>';

		$config['num_tag_open'] = '<li class="page">';
		$config['num_tag_close'] = '</li>';
		if(!empty($this->input->post('name')))
		{
			$name=$this->input->post('name');
			$data['name']= $name;
			$query = $this->db->query("SELECT tbl_bill_cash.*, c.client_name FROM tbl_bill_cash
			INNER JOIN tbl_bill ON tbl_bill_cash.tb_bill_id=tbl_bill.id 
			INNER JOIN tbl_client c ON c.id=tbl_bill.client_id WHERE (tbl_bill.work_year='".$_SESSION['work_year']."')AND( tbl_bill.id LIKE '%".$name."%'  OR c.client_name LIKE '%".$name."%' and tbl_bill.type=''");
			$config["base_url"] = base_url() . "admin/cash_bill/index";
			$config["total_rows"] = $query->num_rows();
			$config["per_page"] = 20;
			$config["uri_segment"] = 4;
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
			$data['ad_prices']= $query->result();
		}
		else
		{
			$query = $this->db->query("SELECT * FROM `tbl_vouchers` where screen ='Cash Bill' 
ORDER BY `tbl_vouchers`.`id`  DESC");
		
			$config["base_url"] = base_url(). "admin/cash_bill/report";
			$config["total_rows"] = $query->num_rows();
			$config["per_page"] = 20;
			$config["uri_segment"] = 4;
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
					$query = $this->db->query("SELECT * FROM `tbl_vouchers` where screen ='Cash Bill' 
ORDER BY `tbl_vouchers`.`id`  DESC");
		
			$data['bills']= $query->result();
		}		
		$data['per_page'] = 20;
		$data['offset'] = $page ;
		$data["total_rows"] = $config["total_rows"];
		
		$this->load->view('admin/header');
		$this->load->view('admin/cash_report_bill_list', $data);
		$this->load->view('admin/footer');
	}
	
	
	
	public function get_view($id)
	{
		$config = array();
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul><!--pagination-->';
		
		$config['first_link'] = '&laquo; First';
		$config['first_tag_open'] = '<li class="prev page">';
		$config['first_tag_close'] = '</li>';

		$config['last_link'] = 'Last &raquo;';
		$config['last_tag_open'] = '<li class="next page">';
		$config['last_tag_close'] = '</li>'; 

		$config['next_link'] = 'Next &rarr;';
		$config['next_tag_open'] = '<li class="next page">';
		$config['next_tag_close'] = '</li>';

		$config['prev_link'] = '&larr; Previous';
		$config['prev_tag_open'] = '<li class="prev page">';
		$config['prev_tag_close'] = '</li>';

		$config['cur_tag_open'] = '<li class="active"><a href="">';
		$config['cur_tag_close'] = '</a></li>';

		$config['num_tag_open'] = '<li class="page">';
		$config['num_tag_close'] = '</li>';
		if(!empty($this->input->post('name')))
		{
			$name=$this->input->post('name');
			$data['name']= $name;
			$query = $this->db->query("SELECT tbl_bill_cash.*, c.client_name FROM tbl_bill_cash
			INNER JOIN tbl_bill ON tbl_bill_cash.tb_bill_id=tbl_bill.id 
			INNER JOIN tbl_client c ON c.id=tbl_bill.client_id WHERE (tbl_bill.work_year='".$_SESSION['work_year']."')AND( tbl_bill.id LIKE '%".$name."%'  OR c.client_name LIKE '%".$name."%' and tbl_bill.type=''");
			$config["base_url"] = base_url() . "admin/cash_bill/index";
			$config["total_rows"] = $query->num_rows();
			$config["per_page"] = 20;
			$config["uri_segment"] = 4;
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
			$data['ad_prices']= $query->result();
		}
		else
		{
			$query = $this->db->query("SELECT tbl_reciept_details.*,tbl_reciept.ClinetName,tbl_bill.bill_date FROM `tbl_reciept` left  JOIN tbl_reciept_details on tbl_reciept_details.receiptno=tbl_reciept.ReceiptNo left JOIN tbl_bill on tbl_bill.id=tbl_reciept_details.Bill_id where tbl_reciept.ReceiptNo='$id'");
		
			$config["base_url"] = base_url(). "admin/cash_bill/index";
			$config["total_rows"] = $query->num_rows();
			$config["per_page"] = 20;
			$config["uri_segment"] = 4;
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
				$query = $this->db->query("SELECT tbl_reciept_details.*,tbl_reciept.ClinetName,tbl_bill.bill_date FROM `tbl_reciept` left  JOIN tbl_reciept_details on tbl_reciept_details.receiptno=tbl_reciept.ReceiptNo left JOIN tbl_bill on tbl_bill.id=tbl_reciept_details.Bill_id where tbl_reciept.ReceiptNo='$id'");
		
		
			$data['bills']= $query->result();
		}		
		$data['per_page'] = 20;
		$data['offset'] = $page ;
		$data["total_rows"] = $config["total_rows"];
		
		$this->load->view('admin/header');
		$this->load->view('admin/cash_bill_list_view', $data);
		$this->load->view('admin/footer');
	}
	
	
	public function add()
	{
		 $this->db->order_by('client_name','ASC');
			$query = $this->db->get('tbl_client');
			$data['clients']= $query->result();
			
			$query5 = $this->db->get('tbl_bank');
			$data['banks']= $query5->result();
			
			$this->load->view('admin/header');
			$this->load->view('admin/cash_bill',$data);
			$this->load->view('admin/footer');
		
	}
	
	
	
	
		public function pay_index()
	{
		$config = array();
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul><!--pagination-->';
		
		$config['first_link'] = '&laquo; First';
		$config['first_tag_open'] = '<li class="prev page">';
		$config['first_tag_close'] = '</li>';

		$config['last_link'] = 'Last &raquo;';
		$config['last_tag_open'] = '<li class="next page">';
		$config['last_tag_close'] = '</li>'; 

		$config['next_link'] = 'Next &rarr;';
		$config['next_tag_open'] = '<li class="next page">';
		$config['next_tag_close'] = '</li>';

		$config['prev_link'] = '&larr; Previous';
		$config['prev_tag_open'] = '<li class="prev page">';
		$config['prev_tag_close'] = '</li>';

		$config['cur_tag_open'] = '<li class="active"><a href="">';
		$config['cur_tag_close'] = '</a></li>';

		$config['num_tag_open'] = '<li class="page">';
		$config['num_tag_close'] = '</li>';
		if(!empty($this->input->post('name')))
		{
			$name=$this->input->post('name');
			$data['name']= $name;
			$query = $this->db->query("SELECT tbl_bill_cash.*, c.client_name FROM tbl_bill_cash
			INNER JOIN tbl_bill ON tbl_bill_cash.tb_bill_id=tbl_bill.id 
			INNER JOIN tbl_client c ON c.id=tbl_bill.client_id WHERE (tbl_bill.work_year='".$_SESSION['work_year']."')AND( tbl_bill.id LIKE '%".$name."%'  OR c.client_name LIKE '%".$name."%' and tbl_bill.type=''");
			$config["base_url"] = base_url() . "admin/cash_bill/index";
			$config["total_rows"] = $query->num_rows();
			$config["per_page"] = 20;
			$config["uri_segment"] = 4;
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
			$data['ad_prices']= $query->result();
		}
		else
		{
			$query = $this->db->query("SELECT tbl_payments.* FROM `tbl_payments`");
		
			$config["base_url"] = base_url(). "admin/cash_bill/pay_index";
			$config["total_rows"] = $query->num_rows();
			$config["per_page"] = 20;
			$config["uri_segment"] = 4;
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
				$query = $this->db->query("SELECT tbl_payments.* FROM `tbl_payments`");
		
		
			$data['bills']= $query->result();
		}		
		$data['per_page'] = 20;
		$data['offset'] = $page ;
		$data["total_rows"] = $config["total_rows"];
		
		$this->load->view('admin/header');
		$this->load->view('admin/pay_bill_list', $data);
		$this->load->view('admin/footer');
	}
	
	
	
	public function get_view_pay($id)
	{
		$config = array();
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul><!--pagination-->';
		
		$config['first_link'] = '&laquo; First';
		$config['first_tag_open'] = '<li class="prev page">';
		$config['first_tag_close'] = '</li>';

		$config['last_link'] = 'Last &raquo;';
		$config['last_tag_open'] = '<li class="next page">';
		$config['last_tag_close'] = '</li>'; 

		$config['next_link'] = 'Next &rarr;';
		$config['next_tag_open'] = '<li class="next page">';
		$config['next_tag_close'] = '</li>';

		$config['prev_link'] = '&larr; Previous';
		$config['prev_tag_open'] = '<li class="prev page">';
		$config['prev_tag_close'] = '</li>';

		$config['cur_tag_open'] = '<li class="active"><a href="">';
		$config['cur_tag_close'] = '</a></li>';

		$config['num_tag_open'] = '<li class="page">';
		$config['num_tag_close'] = '</li>';
		if(!empty($this->input->post('name')))
		{
			$name=$this->input->post('name');
			$data['name']= $name;
			$query = $this->db->query("SELECT tbl_bill_cash.*, c.client_name FROM tbl_bill_cash
			INNER JOIN tbl_bill ON tbl_bill_cash.tb_bill_id=tbl_bill.id 
			INNER JOIN tbl_client c ON c.id=tbl_bill.client_id WHERE (tbl_bill.work_year='".$_SESSION['work_year']."')AND( tbl_bill.id LIKE '%".$name."%'  OR c.client_name LIKE '%".$name."%' and tbl_bill.type=''");
			$config["base_url"] = base_url() . "admin/cash_bill/index";
			$config["total_rows"] = $query->num_rows();
			$config["per_page"] = 20;
			$config["uri_segment"] = 4;
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
			$data['ad_prices']= $query->result();
		}
		else
		{
			$query = $this->db->query("SELECT tbl_reciept_details.*,tbl_reciept.ClinetName,tbl_bill.bill_date FROM `tbl_reciept` left  JOIN tbl_reciept_details on tbl_reciept_details.receiptno=tbl_reciept.ReceiptNo left JOIN tbl_bill on tbl_bill.id=tbl_reciept_details.Bill_id where tbl_reciept.ReceiptNo='$id'");
		
			$config["base_url"] = base_url(). "admin/cash_bill/index";
			$config["total_rows"] = $query->num_rows();
			$config["per_page"] = 20;
			$config["uri_segment"] = 4;
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
				$query = $this->db->query("SELECT tbl_reciept_details.*,tbl_reciept.ClinetName,tbl_bill.bill_date FROM `tbl_reciept` left  JOIN tbl_reciept_details on tbl_reciept_details.receiptno=tbl_reciept.ReceiptNo left JOIN tbl_bill on tbl_bill.id=tbl_reciept_details.Bill_id where tbl_reciept.ReceiptNo='$id'");
		
		
			$data['bills']= $query->result();
		}		
		$data['per_page'] = 20;
		$data['offset'] = $page ;
		$data["total_rows"] = $config["total_rows"];
		
		$this->load->view('admin/header');
		$this->load->view('admin/cash_bill_list_view', $data);
		$this->load->view('admin/footer');
	}
	
	
	public function add_pay()
	{
		 $this->db->order_by('ng_id','ASC');
			$query = $this->db->get('tbl_news_group');
			$data['clients']= $query->result();
			
			
			$this->load->view('admin/header');
			$this->load->view('admin/cash_bill_pay',$data);
			$this->load->view('admin/footer');
		
	}

	









	public function get($id)
	{	
		if(!empty($this->input->post()))
		{
			$this->form_validation->set_rules('net', 'Net', 'required');
			if ($this->form_validation->run() == FALSE) 
			{
				$query = $this->db->get_where('tbl_book_ads', array('id' => $id));
				$ro= $query->row();
			
				$book_ads=$this->db->query("SELECT tbl_book_ads.*, n.name as newspaper_name, t.name as type_name, c.name as cat_name, u.email, u.mobile, u.client_name, u.discount as client_discount FROM tbl_book_ads
				INNER JOIN tbl_newspapers n ON n.id=tbl_book_ads.newspaper_id
				INNER JOIN tbl_news_type t ON t.id=tbl_book_ads.type_id
				INNER JOIN tbl_categories c ON c.id=tbl_book_ads.cat_id
				INNER JOIN tbl_client u ON u.id=tbl_book_ads.u_id WHERE tbl_book_ads.id='".$id."' and  tbl_book_ads.work_year='".$_SESSION['work_year']."'");
				$book_ad= $book_ads->row();
			
				$data['book_ad']=$book_ad;
				$data['discount']=$book_ad->ad_cost*$book_ad->client_discount/100;
				$data['net']=$book_ad->ad_cost-$data['discount'];
			
				$this->load->view('admin/header');
				$this->load->view('admin/client_bill_get',$data);
				$this->load->view('admin/footer');
			}
			else
			{
				$values = array(
					'ro_id' => $id,
					'client_id' => $this->input->post('c_id'),
					'amount' => $this->input->post('amt'),
					'box_charges' => $this->input->post('bc'),
					'el_charges' => $this->input->post('elc'),
					'non_focus' => $this->input->post('nfd'),
					'premium' => $this->input->post('premium'),
					'total' => $this->input->post('total'),
					'discount' => $this->input->post('dis'),
					'at_work_charges' => 0,
					'net_amount' => $this->input->post('net'),
					'bill_date' => date('Y-m-d')
				);
				
				$query = $this-> db->insert('tbl_bill', $values);
				$in_id=$this->db->insert_id();

				$query = $this->db->get_where('tbl_client', array('id' => $values['client_id']));
				$client= $query->row();
				
				$query = $this->db->get_where('tbl_book_ads', array('id' => $id));				
				$ro= $query->row();	
			
				if($ro->pending=='C')
				{
					if(($client->credit_bal-$values['amount'])>0)
					{					
						$bal=$client->credit_bal-$values['amount'];
						$values = array('credit_bal' =>$bal);
						$this->db->update('tbl_client',$values, "id =".$client->id);
					}
				}
				else
				{
					$values = array('pending' => 'C');
					$this->db->update('tbl_book_ads',$values, "id =".$id);	
				}
			
				$values = array('status' => 'I');
				$this->db->update('tbl_book_ads',$values, "id =".$id);	
				$this->session->set_flashdata('msg', 'Bill Successfully add');
			
				$query = $this->db->get_where('tbl_book_ads', array('id' => $id));
				$ro= $query->row();
			
				redirect('admin/client_bill/add/'.$ro->u_id);
			}
		}
		else
		{
		
			$query = $this->db->get_where('tbl_book_ads', array('id' => $id));
			$ro= $query->row();
			
			$book_ads=$this->db->query("SELECT tbl_book_ads.*, n.name as newspaper_name, t.name as type_name, c.name as cat_name, u.email, u.mobile, u.client_name, u.discount as client_discount FROM tbl_book_ads
			INNER JOIN tbl_newspapers n ON n.id=tbl_book_ads.newspaper_id
			INNER JOIN tbl_news_type t ON t.id=tbl_book_ads.type_id
			INNER JOIN tbl_categories c ON c.id=tbl_book_ads.cat_id
			INNER JOIN tbl_client u ON u.id=tbl_book_ads.u_id WHERE tbl_book_ads.id='".$id."' and tbl_book_ads.work_year='".$_SESSION['work_year']."'");
			$book_ad= $book_ads->row();
			
			$data['book_ad']=$book_ad;
			$data['discount']=$book_ad->client_discount;
			
			$query = $this->db->get('tbl_tax');
			$data['taxs']= $query->result();
			
			
			$this->load->view('admin/header');
			$this->load->view('admin/client_bill_get',$data);
			$this->load->view('admin/footer');
		
		}
	}

	public function save_bill()
	{
$this->load->model("site_model");
				
		if (!empty($this->input->post())) 
		{
			$this->form_validation->set_rules('received', 'Amount', 'required');			
			$this->form_validation->set_rules('tb_bill_id', 'Bill', 'required');			
			$this->form_validation->set_rules('client', 'client', 'required');
			if ($this->form_validation->run() == FALSE) 
			{
				$msg="1";
				echo $msg;
				return;
			}
			else
			{
				
				 $received=$this->input->post('received');
				 $bill_date=$this->input->post('bill_date');
				 $client=$this->input->post('client');
				 $payment_mode=$this->input->post('payment_mode');
				 $tb_bill_id=json_encode($this->input->post('tb_bill_id'));
				 $deposit_bank=$this->input->post('deposit_bank');
				 $bank=$this->input->post('bank');
				 
				 $cheque_no=$this->input->post('cheque_no');
				 $data['Amount'] =$received;
				 $data['Dated'] =date('Y-m-d',strtotime($bill_date));
				 $data['PayMode'] =$payment_mode;
				 $data['Bank'] =$bank;
				 $data['ChNo'] =$cheque_no;
				 $data['ClinetId'] =$client;
				 $data['ClinetName'] = $this->site_model->get_data("tbl_client",['id'=>$client])[0]['client_name'];
				$this->site_model->insert_data('tbl_reciept',$data);
				$client_name = $data['ClinetName'] ;
				$recep_no = $this->db->insert_id();
				$tb_bill_id = explode(',',rtrim($this->input->post('tb_bill_id'),','));
				
							       	$values = array(
            						'group_id'=>3,
            						'ledger_id'=>739,
            						'voucher_date'=> date("Y-m-d H:i:s"),
            						'entry_type'=>'dr',
            						'amount'=>$received,
            						'narration'=>"Cash   Recepit No: ".$recep_no,
            						'voucher_no'=>1,
            						'screen'=>"Cash Bill",
            						'screen_id'=>$client,
            						'voucher_session'=>1
            					);
            					$this->site_model->insert_data('tbl_vouchers', $values); 	
            			        $ledger_id = $result['ledger_id'];
            					 $sdds=    $this->site_model->get_data("tbl_ledgers",['ledger_name'=>$client_name]);
            					if(empty($sdds)){
            						$values = array(
            							'group_id'=>2,
            							'master_id'=> $client,
            							'ledger_name'=> $client_name,
            							'opening_balance'=>0,
            							'editable'=>'no'
            						);
            						$ledger_id=$this->site_model->insert_data('tbl_ledgers', $values); 
            					} else {
            					    
            					  $ledger_id =$sdds[0]['ledger_id'];   
            					}		
            					  	$values = array(
            						'group_id'=>$client,
            						'ledger_id'=>$ledger_id,
            						'voucher_date'=> date('Y-m-d',strtotime($bill_date)),
            						'entry_type'=>'cr',
            						'amount'=>$received,
            						'narration'=>"Cash credit : ".$client_name,
            						'voucher_no'=>1,
            						'screen'=>"Cash Bill",
            						'screen_id'=>$client,
            						'voucher_session'=>1
            					);
            					$this->site_model->insert_data('tbl_vouchers', $values); 				
				foreach($tb_bill_id as $tb_bill){
				    $res=$this->site_model->get_data("tbl_bill",['id'=>$tb_bill])[0];
				   $tb_bill_no = $res['bill_no'];
		$query1=$this->db->query("SELECT Net FROM `tbl_reciept_details`
		
		WHERE
		`tbl_reciept_details`.`Bill_id`=$tb_bill order by Reciept_No desc ");
		$queryw = $query1->row();
		    if($queryw){
		   $res['net_amount'] = $queryw->Net; 
		        
		    } else {
		   $res['net_amount'] = number_format($res['net_amount'],2); 
		    }
		    $res['net_amount'] = str_replace(',','',$res['net_amount']);
		
				/*$res=$this->site_model->get_data("tbl_bill",['id'=>$tb_bill])[0];
				$bdata['id'] = $res['id'];
					
					if($res['net_amount']>$received){
					$net_amount = $res['net_amount']-$received;
					$bdata['net_amount'] = $net_amount;
					} else {
					$net_amount = $received-$res['net_amount'];
					$bdata['net_amount'] = 0;
						
					}
					$received = $net_amount;
					$this->site_model->update_data('tbl_bill',$bdata,array('id'=> $tb_bill));*/
					if($res['net_amount']>$received){
					$received = $net_amount = $res['net_amount']-$received;
					$bdata['Net'] = $net_amount;
					 $bdata['Status'] ='pending';
				
					} else if($res['net_amount']<$received){
					$received = $received-$res['net_amount'];
					    
					 	$bdata['Net'] = 0;
					 $bdata['Status'] ='pending';
				   
					} else {
					$received = $net_amount = $received-$res['net_amount'];
					$bdata['Net'] = $net_amount;
					 $bdata['Status'] ='complated';
				
						
					}
				$bdata['receiptno']=$recep_no ;	
				 $bdata['Bill_id'] =$tb_bill;
				 if($payment_mode=='Cash'){
			    	 $bdata['type'] ='dr';
			    	 
			    	 
				     
				 }

     
				 if($payment_mode=='bank'){
			    	 $bdata['type'] ='cr';
			    	 
			    	
				     
				 }
				 $bdata['Bill_No'] =$tb_bill_no;
				 $bdata['Bill_Date'] =date('Y-m-d',strtotime($bill_date));
				 $bdata['MediaAmount'] =$res['amount'];
				 $bdata['Bill_Amount'] =str_replace(',','',$res['net_amount']);
				//print_r($bdata);
				$this->site_model->insert_data('tbl_reciept_details',$bdata);
			
					
				}
					$msg="5";
				echo $msg;
				return;
			
				 
			}			
		}
	}
	
	
		public function save_get_bill()
	{
$this->load->model("site_model");
				
		if (!empty($this->input->post())) 
		{
			$this->form_validation->set_rules('received', 'Amount', 'required');			
			$this->form_validation->set_rules('tb_bill_id', 'Bill', 'required');			
			$this->form_validation->set_rules('client', 'client', 'required');
			if ($this->form_validation->run() == FALSE) 
			{
				$msg="1";
				echo $msg;
				return;
			}
			else
			{
				
				 $received=$this->input->post('received');
				 $bill_date=$this->input->post('bill_date');
				 $client=$this->input->post('client');
				 $payment_mode=$this->input->post('payment_mode');
				 $tb_bill_id=json_encode($this->input->post('tb_bill_id'));
				 $deposit_bank=$this->input->post('deposit_bank');
				 $cheque_no=$this->input->post('cheque_no');
				 $data['Amount'] =$received;
				 $data['Dated'] =date('Y-m-d',strtotime($bill_date));
				 $data['PayMode'] =$payment_mode;
				 $data['Bank'] =$deposit_bank;
				 $data['ChNo'] =$cheque_no;
				 $data['ClinetId'] =$client;
				 $data['ClinetName'] = $this->site_model->get_data("tbl_news_group",['ng_id'=>$client])[0]['ng_name'];
				$this->site_model->insert_data('tbl_payments',$data);
				$client_name = $data['ClinetName'] ;
				$recep_no = $this->db->insert_id();
				$tb_bill_id = explode(',',rtrim($this->input->post('tb_bill_id'),','));
				
							       	$values = array(
            						'group_id'=>3,
            						'ledger_id'=>739,
            						'voucher_date'=> date("Y-m-d H:i:s"),
            						'entry_type'=>'dr',
            						'amount'=>$received,
            						'narration'=>"Cash   Recepit No: ".$recep_no,
            						'voucher_no'=>1,
            						'screen'=>"Cash Bill",
            						'screen_id'=>$client,
            						'voucher_session'=>1
            					);
            					$this->site_model->insert_data('tbl_vouchers', $values); 	
            					
            									       	$values = array(
            						'group_id'=>$client,
            						'ledger_id'=>$client,
            						'voucher_date'=> date("Y-m-d H:i:s"),
            						'entry_type'=>'cr',
            						'amount'=>$received,
            						'narration'=>"Cash credit : ".$client_name,
            						'voucher_no'=>1,
            						'screen'=>"Cash Bill",
            						'screen_id'=>$client,
            						'voucher_session'=>1
            					);
            					$this->site_model->insert_data('tbl_vouchers', $values); 				
				foreach($tb_bill_id as $tb_bill){
				    $res=$this->site_model->get_data("tbl_publication_bill",['id'=>$tb_bill])[0];
				   $tb_bill_no = $res['bill_no'];
		$query1=$this->db->query("SELECT Net FROM `tbl_payments_details`
		
		WHERE
		`tbl_payments_details`.`Bill_id`=$tb_bill order by Reciept_No desc ");
		$queryw = $query1->row();
		    if($queryw){
		   $res['net_amount'] = $queryw->Net; 
		        
		    } else {
		   $res['net_amount'] = number_format($res['net_amount'],2); 
		    }
		
				/*$res=$this->site_model->get_data("tbl_bill",['id'=>$tb_bill])[0];
				$bdata['id'] = $res['id'];
					
					if($res['net_amount']>$received){
					$net_amount = $res['net_amount']-$received;
					$bdata['net_amount'] = $net_amount;
					} else {
					$net_amount = $received-$res['net_amount'];
					$bdata['net_amount'] = 0;
						
					}
					$received = $net_amount;
					$this->site_model->update_data('tbl_bill',$bdata,array('id'=> $tb_bill));*/
					if($res['net_amount']>$received){
					$net_amount = $res['net_amount']-$received;
					$bdata['Net'] = $net_amount;
					 $bdata['Status'] ='pending';
				
					} else {
					$net_amount = $received-$res['net_amount'];
					$bdata['Net'] = $net_amount;
					 $bdata['Status'] ='complated';
				
						
					}
				$bdata['receiptno']=$recep_no ;	
				 $bdata['Bill_id'] =$tb_bill;
				 if($payment_mode=='Cash'){
			    	 $bdata['type'] ='dr';
			    	 
			    	 
				     
				 }

     
				 if($payment_mode=='bank'){
			    	 $bdata['type'] ='cr';
			    	 
			    	
				     
				 }
				 $bdata['Bill_No'] =$tb_bill_no;
				 $bdata['Bill_Date'] =date('Y-m-d',strtotime($bill_date));
				 $bdata['MediaAmount'] =$res['bill_amount'];
				 $bdata['Bill_Amount'] =$received;
				
				$this->site_model->insert_data('tbl_payments_details',$bdata);
			
					
				}
					$msg="5";
				echo $msg;
				return;
			
				 
			}			
		}
	}
	

	public function update_bill()
	{
		if (!empty($this->input->post())) 
		{
			$this->form_validation->set_rules('amount', 'Amount', 'required');			
			$this->form_validation->set_rules('net_amount', 'Net Amount', 'required');
			$this->form_validation->set_rules('due_day', 'Due Day', 'required');
			$this->form_validation->set_rules('total', 'total', 'required');
			$this->form_validation->set_rules('client', 'client', 'required');
			if ($this->form_validation->run() == FALSE) 
			{
				$msg="1";
				echo $msg;
				return;
			}
			else
			{
				/******************************/
				/* Code to retrive bill_no */
				/*****************************/
				 $rembill=$_POST['remove_bill'];
				 $cancel_parties=$_POST['cancel_parties'];
				 
				 if(!empty($cancel_parties))
				 {
				     
				     foreach($cancel_parties as $cparty)
				     {
				         $this->db->query("update tbl_bill set Shared_Status='".Cancel."' where id='$cparty'");
				           $this->db->query("delete from tbl_bill_details  where bill_id='$cparty'");
				         $this->db->query("DELETE from tbl_vouchers where group_id= '2' and screen='Client Bill' and screen_id='$cparty'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '9' and ledger_id='12' and screen='Client Bill' and screen_id='$cparty'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '7' and ledger_id='9' and screen='Client Bill' and screen_id='$cparty'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '15' and ledger_id='13' and screen='Client Bill' and screen_id='$cparty'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '15' and ledger_id='14' and screen='Client Bill' and screen_id='$cparty'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '15' and ledger_id='15' and screen='Client Bill' and screen_id='$cparty'");
				     
				    }
				 }
				  $bill_id=$this->input->post('bill_id');
				     for($i=0;$i<count($rembill);$i++)
				     {
                    	      //query to add insertions back into the tbl_book_ads//
                    	      	$query=$this->db->query("select * from tbl_bill_details where bill_id ='".$bill_id."' and ro_id='$rembill[$i]'" );
                                						$ro_data=$query->result();
                                						$insertion=$ro_data[0]->insertion;
                                					
                                					   $resultbook=$this->db->select("*")->where(["id"=>$rembill[$i]])->get("tbl_book_ads")->row();
                                					   	
                    						            $this->db->where('id',$rembill[$i]);
                                        	            $this->db->update("tbl_book_ads",["publish_day"=>($resultbook->publish_day+$insertion)]);
                                					
                    	      
                    	      	
                    	   foreach($ro_data as $rod)
                    	   {
                    				    
                                    					                    $this->db->query("UPDATE `tbl_ro_dop` set `bill_dop`='', bill_status='N',bill_number='0' where  `id`=$rod->ro_main_id ");
                                    		
                                    					         
                    		}
                    	 
                    	  
                    	
                             $this->db->query("delete from tbl_bill_details where ro_id ='".$rembill[$i]."' and bill_id ='".$bill_id."' " );
                    
                    
                         
				     }
				 
//echo"select * from tbl_bill_details where bill_id ='".$bill_id."' and ro_id='$rembill[0]'";
			    
			    //die;
			  //  $ro_main_id =$this->input->post('ro_main_id');
			    
			  
			    //$bill_id;
			    $sqlbill=$this->db->query("select * from `tbl_bill` where `id`='".$bill_id."'");
	

			    $resultbill=$sqlbill->row();
			    
			    	$bill_no=$resultbill->bill_no;
			    
			  
			    $shared_client=$this->input->post('shared_client');
		 if(!empty($shared_client))
			   {
			    
			       $amount=0;
			        $count=count($shared_client);
			        array_unshift($shared_client,$this->input->post('client'));
    			    $shared_per =$this->input->post('shared_per');
    			  //echo "</br>";
    			    $main_shared_per =$this->input->post('mshare');
    			 //  echo "</br>";
    			 // echo $shared_per;
    			 // echo $count;die;
    			   $mshare=floatval(($this->input->post('amount'))*floatval($main_shared_per)/100);
    			   $s_share=floatval(($this->input->post('amount'))*floatval($shared_per)/100)/floatval($count);
    			 //  echo "mshare".$mshare;
    			 //   echo "</br>";
    			 //  echo "share".$s_share;
    			 //   echo "</br>";
    			 //  die;
				 $this->load->model("site_model");
		
    			$pshare=floatval($shared_per)/floatval($count);
    // 			echo $pshare;
    // 		echo number_format($pshare,2);
    // 		die;
    			 $shared_id='';
			           $Shared_amount='';
			            foreach($shared_client as $cs)
			            {
    			                if($cs==$this->input->post('client'))
    			                {
    			                  $Shared_amount=$main_shared_per;
    			                    $amount =$mshare;
    			                }
    			               else
    			               {
    			                    $Shared_amount=number_format($pshare,2);
    			                    $amount =$s_share;
    			               }
			                 $query=$this->db->query("SELECT id from states where name=(SELECT state FROM `tbl_client_details` where uid='$cs' limit 1)");
							$gst=$this->site_model->get_gst(date('Y-m-d'),date('Y-m-d'));
            					
    			              $state=$query->row();
    			             
    			             
    			                 if($state->id==null){
                                    $cgst=(floatval($amount)*$gst)/100;
                                    $sgst=(floatval($amount)*$gst)/100;
                                    $igst=0;	
                                }
                                else if($state->id=="6"){
                                    $cgst=(floatval($amount)*$gst)/100;
                                    $sgst=(floatval($amount)*$gst)/100;
                                    $igst=0;
                                }
                                else{
                                    $cgst=0;
                                    $sgst=0;
                                    $igst=(floatval($amount)*$gst)/100;
                                }
			               $total=$amount+$this->input->post('box_c');
			               $net_amount=$total+ $this->input->post('dis_per')+$this->input->post('discount')+$this->input->post('art_work_charges')+$this->input->post('other_charges')+$igst+$cgst+$sgst;
			               
			            	$tbl_bill_temp=$this->db->where(['client_id'=>$this->input->post('client')])->get("tbl_bill_temp");
			            
			       
            				// if($tbl_bill_temp->num_rows()==0)
            				// {
            				// 	$msg="2";
            				// 	echo $msg;
            				// 	return;
            				// }
            				// else
            				// {
            				 	$this->load->model("site_model");
            			
            					$res=$this->site_model->get_data("tbl_client",['id'=>$cs])[0];
            					$client_name=$res['client_name'];
            					  
            					
            					//echo '<pre>'; var_dump($_POST); die;
            					$days=$this->input->post('due_day')." days";
                                
                                
                                $dt=new DateTime($this->input->post('bill_date'));
                                $bill_date=$dt->format("Y-m-d");    
                                

                                $due_date=date('Y-m-d',strtotime( $bill_date . ' +30 day'));
            					//$date=date_create();
            					//date_add($date,date_interval_create_from_date_string($days));
            					//$due_date=date_format($date,"Y-m-d");
            				//	$bill_no=bill_no_gen();
                                  if($cs==$this->input->post('client'))
    			                {
    			                    $shared_id='';
    			                    
    			                } 
    			                else
    			                {
    			                     $shared_id=$bill_id;
    			                }
                               
            					$values = array(
            						
            						
            				 		'client_id'=> $cs,
            				 		'emp_id'=>$_SESSION['admin']['id'],
                                    'bill_date'=> $bill_date,
            						'amount'=> floatval($amount),
            						'box_charges'=> $this->input->post('box_c'),
            						'total'=> $total,
            						'dis_per'=> $this->input->post('dis_per'),
            						'discount'=> $this->input->post('discount'),
            						'art_work_charges'=> $this->input->post('art_work_charges'),
            						'other_charges'=> $this->input->post('other_charges'),
            						'net_amount'=> $net_amount,
            						'igst'=> $igst,
            						'cgst'=>$cgst,
            						'sgst'=>$sgst,
            						'due_date'=> $due_date,
            						'Shared'=>'YES',
						            'Shared_id'=>$shared_id,
						             'Shared_Per'=>$Shared_amount
            					);
            			//	$query = $this->db->update('tbl_bill', $values,['id'=>$bill_id]);
            			//	echo $this->db->last_query();   
            				if($cs==$this->input->post('client'))
            				{
            				$this->db->where(['id'=>$bill_id])->update('tbl_bill', $values);
            			//	echo $this->db->last_query();
            				$in_id=$bill_id;
            				}
            				else
            				{
            				    $findCl=$this->db->query("select * from tbl_bill where Shared_id='$bill_id' and client_id='$cs' and Shared_Status!='Cancel'");
            				 //  echo $this->db->last_query();
            				    $clRes=$findCl->row();
            				    if(!empty($clRes))
            				    {
            				        
            				        if($cs==$clRes->client_id)
            				        {
            				        $this->db->where(['id'=>$clRes->id])->update('tbl_bill', $values);
            				      //  echo $this->db->last_query();
            				        $in_id=$clRes->id;
            				        }
            				       
            				        
            				    }
            				    else
            				    {
            				       	$bill_no=bill_no_gen();
                                                
                                
            					$values = array(
            						'bill_no'=>$bill_no,
            						'work_year'=> $_SESSION['work_year'],
            						'client_id'=> $cs,
            						'emp_id'=>$_SESSION['admin']['id'],
                                    'bill_date'=> $bill_date,
            						'amount'=> floatval($amount),
            						'box_charges'=> $this->input->post('box_c'),
            						'total'=> $total,
            						'dis_per'=> $this->input->post('dis_per'),
            						'discount'=> $this->input->post('discount'),
            						'art_work_charges'=> $this->input->post('art_work_charges'),
            						'other_charges'=> $this->input->post('other_charges'),
            						'net_amount'=> $net_amount,
            						'igst'=> $igst,
            						'cgst'=>$cgst,
            						'sgst'=>$sgst,
            						'due_date'=> $due_date,
            						'Shared'=>'YES',
						            'Shared_id'=>$shared_id,
						            'Shared_Per'=>$Shared_amount
            					);
            					$query = $this->db->insert('tbl_bill', $values);
            		//	echo $this->db->last_query();
            					$in_id=$this->db->insert_id(); 
            				    }
            				}
            			
           
            					$result=$this->site_model->get_data("tbl_ledgers",['master_id'=>$cs])[0];
            			$this->db->query("DELETE from tbl_vouchers where group_id= '2' and screen='Client Bill' and screen_id='$in_id'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '9' and screen='Client Bill' and ledger_id='12' and screen_id='$in_id'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '7' and screen='Client Bill' and ledger_id='9' and screen_id='$in_id'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '15' and screen='Client Bill' and ledger_id='13' and screen_id='$in_id'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '15' and screen='Client Bill' and ledger_id='14' and screen_id='$in_id'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '15' and screen='Client Bill' and ledger_id='15' and screen_id='$in_id'");
            					$ledger_id=$result['ledger_id'];
            					if(empty($result['ledger_id'])){
            						$values = array(
            							'group_id'=>2,
            							'master_id'=> $cs,
            							'ledger_name'=> $client_name,
            							'opening_balance'=>0,
            							'editable'=>'no'
            						);
            						$ledger_id=$this->site_model->insert_data('tbl_ledgers', $values); 
            					//	echo $this->db->last_query(); 
            					}
            
            					$values = array(
            						'group_id'=>2,
            						'ledger_id'=> $ledger_id,
            						'voucher_date'=> date("Y-m-d H:i:s"),
            						'entry_type'=>'dr',
            						'amount'=>$amount-$this->input->post('discount')+$igst+$sgst+$cgst+$this->input->post('box_c')+$this->input->post('at_w')+$this->input->post('other_c'),
            						'narration'=>"Bill generated for ".$client_name."No: ".$bill_no,
            						'voucher_no'=>1,
            						'screen'=>"Client Bill",
            						'screen_id'=>$in_id,
            						'voucher_session'=>1
            					);
            					$this->site_model->insert_data('tbl_vouchers', $values); 
            	
            
            					$values = array(
            						'group_id'=>9,
            						'ledger_id'=>12,
            						'voucher_date'=> date("Y-m-d H:i:s"),
            						'entry_type'=>'cr',
            						'amount'=>$this->input->post('discount'),
            						'narration'=>"Discount generated for ".$ledger_name." Bill No: ".$bill_no,
            						'voucher_no'=>1,
            						'screen'=>"Client Bill",
            						'screen_id'=>$in_id,
            						'voucher_session'=>1
            					);
            					$this->site_model->insert_data('tbl_vouchers', $values); 
            			//	echo $this->db->last_query(); 
            
            					$values = array(
            						'group_id'=>7,
            						'ledger_id'=>9,
            						'voucher_date'=> date("Y-m-d H:i:s"),
            						'entry_type'=>'cr',
            						'amount'=>$amount+$this->input->post('box_c')+$this->input->post('at_w')+$this->input->post('other_c'),
            						'narration'=>"Advertisement Income on Bill No: ".$bill_no,
            						'voucher_no'=>1,
            						'screen'=>"Client Bill",
            						'screen_id'=>$in_id,
            						'voucher_session'=>1
            					);
            					$this->site_model->insert_data('tbl_vouchers', $values); 
            				//	echo $this->db->last_query(); 
            
            					if($igst){
            					$values = array(
            						'group_id'=>15,
            						'ledger_id'=>13,
            						'voucher_date'=> date("Y-m-d H:i:s"),
            						'entry_type'=>'cr',
            						'amount'=>$igst,
            						'narration'=>"IGST on Bill No: ".$bill_no,
            						'voucher_no'=>1,
            						'screen'=>"Client Bill",
            						'screen_id'=>$in_id,
            						'voucher_session'=>1
            					);
            					$this->site_model->insert_data('tbl_vouchers', $values); 
            				//	echo $this->db->last_query(); 
            					}
            
            					if($cgst){
            					$values = array(
            						'group_id'=>15,
            						'ledger_id'=>14,
            						'voucher_date'=> date("Y-m-d H:i:s"),
            						'entry_type'=>'cr',
            						'amount'=>$cgst,
            						'narration'=>"CGST on Bill No: ".$bill_no,
            						'voucher_no'=>1,
            						'screen'=>"Client Bill",
            						'screen_id'=>$in_id,
            						'voucher_session'=>1
            					);
            					$this->site_model->insert_data('tbl_vouchers', $values); 
            			//	echo $this->db->last_query(); 
            				}
            
            				if($sgst){
            					$values = array(
            						'group_id'=>15,
            						'ledger_id'=>15,
            						'voucher_date'=> date("Y-m-d H:i:s"),
            						'entry_type'=>'cr',
            						'amount'=>$sgst,
            						'narration'=>"UGST on Bill No: ".$bill_no,
            						'voucher_no'=>1,
            						'screen'=>"Client Bill",
            						'screen_id'=>$in_id,
            						'voucher_session'=>1
            					);
            					$this->site_model->insert_data('tbl_vouchers', $values); 
            				//	echo $this->db->last_query(); 
            				}
            
            					//echo $this->db->last_query(); return;
            					//$in_id=$this->db->insert_id();
            					$result=$tbl_bill_temp->result();
            					
            					$bill_detail=array();
            					$c=0;
                                 $heading_main=0;
            					$days=array();
            			foreach($result as $ro){
					     $this->db->query("INSERT INTO `tbl_bill_edit`( `bill_id`, `ro_id`, `work_year`, `ro_no`, `client_id`, `emp_id`, `newspaper_id`, `type_id`, `cat_id`, `size_words`, `min_w`, `insertion`, `p_date`, `price`, `eprice`, `amount`, `scheme`, `pack`, `premimum`, `extra_price`, `add_on_amount`, `dis_per`, `discount`, `height`, `width`, `box_charges`, `payable_amount`, `ro_date`) values ('$in_id', '$ro->ro_id', '$ro->work_year', '$ro->ro_no', '$ro->client_id', '$ro->emp_id', '$ro->newspaper_id', '$ro->type_id', '$ro->cat_id', '$ro->size_words', '$ro->min_w', '$ro->insertion', '$ro->p_date', '$ro->price', '$ro->eprice', '$ro->amount', '$ro->scheme', '$ro->pack', '$ro->premimum', '$ro->extra_price', '$ro->add_on_amount', '$ro->dis_per', '$ro->discount', '$ro->height', '$ro->width', '$ro->box_charges', '$ro->payable_amount', '$ro->ro_date' ) ");    
                      
						$values1['box_charges']=$ro->box_charges;
						//$values1['p_amount']=($ro->amount+$ro->discount);
						$values1['status']="Y";
				
						/************* Enter into tbl_bill_details *********************************/
            					
            						  $tempdop=$ro->p_date;
                                    		    $tempro_id=$ro->ro_id;
                                    		    $Free=$ro->Free;
                                    		    $Paid=$ro->Paid;
                                    		  $size_type=$ro->size_type;
                                    		    $p_datetemp=explode(',',$tempdop);
                                    		    $pcount=1;
                                    		   
                                    		    foreach($p_datetemp as $dt)
                                    		    { 
                                    		        $ddtemp=date('Y-m-d',strtotime($dt));
                                    		        $query2=$this->db->query("select * from tbl_ro_dop where ro_id='$tempro_id' and dop='$ddtemp'");
                                    		       
                                    		        $result1=$query2->row();
                                    		        
                                    		        $dop_amount=floatval($result1->dop_amount);
                                    		       // $values1['insertion']=1;
                                    		        
                                                            	$c_amount=0;
                                    							$p_amount=0;
                                                                $discount=0;
                                    							 $extra_price=floatval($ro->eprice);
                                    				            $box_charges=floatval($ro->box_charges);
                                    				           
                                    				            if($ro->type_id==2|| $ro->type_id==3)
                                    				            {
                                    				            if($size_type=="F")
                                    				                {
                                    				                    	$c_amount+=floatval($ro->price)*(1);
                                    				                }
                                    				                else
                                    				                {
                                    				            	$word_size=split('X',$ro->size_words);
                                    				            	$len=$word_size[0];
                                    				            	$width=$word_size[1];
                                    				            	$c_amount+=floatval($ro->price)*floatval($len)*floatval($width)*(1);
                                    				                }
                                    				            }
                                    				            else
                                    				            {
                                    				               
                                    				            $c_amount+= floatval($ro->price)+(floatval($ro->size_words-$ro->min_w)*floatval($ro->eprice));
                                    				            
                                    				        	}
                                    				            $prem=explode(",",$ro->premimum);
                                                                $am=$c_amount;
                                    				           if($prem[1] == 'Rs')
                                    				            { 
                                    				                $premimum=($am)+$prem[0];
                                    				            }
                                    				            if($prem[1] == '%')
                                    				            {
                                    				                $premimum=($am*$prem[0])/100;
                                    				               
                                    				            }
                                                                
                                                                
                                                                if($premimum==NULL)
                                                                {
                                                                    $premimum=0;
                                                                }
                                    				            //premimum+=parseFloat(d.premimum);
                                    				            $dis_per=$ro->dis_per;
                                    				          
                                    				             $c_amount=$c_amount+$premimum;
                                    				            $dis=($c_amount*$dis_per)/100;
                                    				           //$premimum
                                    				             $p_amount=$c_amount-$dis+$box_charges;
                                    				             $discount=$dis;
                                    				         	      
                                    				             $heading_main=$ro->cat_id;
                                            						$values1=array();
                                            						$values1['ro_main_id']=$result1->id;
                                            						$values1['bill_id']=$in_id;
                                            						$values1['ro_id']=$ro->ro_id;
                                            						$values1['type_id']=$ro->type_id;
                                            						$values1['ro_session']=$ro->work_year;
                                            						$values1['insertion']=$ro->insertion;
                                            						$values1['pub_date']=$ddtemp;
                                            						$values1['paper']=$ro->newspaper_id;
                                            						$values1['heading']=$ro->cat_id;
                                            						$values1['pack']=$ro->pack;
                                            						$values1['scheme']=$ro->scheme;
                                            						$values1['premimum']=$ro->premimum;
                                            						$values1['premimum_val']=$premimum;
                                            						$values1['word_size']=$ro->size_words;
                                            						$values1['rate']=$ro->price;
                                            						$values1['e_rate']=$ro->eprice;
                                            						$values1['min_w']=$ro->min_w;
                                            						 $values1['amount']=$c_amount;
                                            						 $values1['box_charges']=$box_charges;
                                            						$values1['dis_per']=$ro->dis_per;
                                            					    $values1['discount']=$dis;
                                    				                 $values1['net_amount']=$p_amount;
                                    				                 $values1['status']="Y";
                                    				                
                                    				                  $values1['Ad_type']="Paid";
                                    				                  $values1['size_type']=$size_type;
                                    				                   
                                    				                   if($pcount > $Paid)
                                    				          
                                    				           {
                                    				               $values1['amount']=0;
                                    				               $values1['discount']=0;$values1['net_amount']=0;
                                    				               $values1['Ad_type']="Free";
                                    				           }
                                    		   
            						            $this->db->insert('tbl_bill_details', $values1);
            						            
            						            	$pcount++;
                                    		    }
            						//echo $this->db->last_query();
            /************* Enter into tbl_bill_details *********************************/
            						$resp=$this->site_model->get_data("tbl_bill_temp_details",['ro_id'=>$ro->ro_id]);
            						$pcount1=1;
            						if(!empty($resp))
            						{
            						foreach($resp as $row){
            						  
                                    		        $query=$this->db->query("select * from tbl_ro_dop where id='".$row['ro_main_id']."'");
                                    		       
                                    		        $result2=$query->row();
                                    		        $dop_amount2=floatval($result2->dop_amount);
            						                  $c_amount=0;
                                    							$p_amount=0;
                                                                $discount=0;
                                    							 $extra_price=floatval($row['erate']);
                                    				            $box_charges=floatval($ro->box_charges);
                                    				            if($row['type_id']==2 || $row['type_id']==3)
                                    				            {
                                    				                 if($size_type=="F")
                                    				                {
                                    				                    	$c_amount+=floatval($row['rate'])*(1);
                                    				                }
                                    				                else
                                    				                {
                                    				               $xx =$ro->size_words;
                                    				            	$word_size=split("X",$xx);
                                    				            	 $len=$word_size[0];
                                    				             	$width=$word_size[1];
                                    				             
                                    				            	$c_amount+=$row['rate']*floatval($len)*floatval($width)*(1);
                                    				                }
                                    				            
                                    				            }
                                    				            else
                                    				            {
                                    				            $c_amount+=floatval($row['rate'])+(floatval($ro->size_words-$ro->min_w)*floatval($row['erate']));
                                    				        	}
                                    				             $prem=explode(",",$ro->premimum);
                                                                 $am=$c_amount;
                                    				            if($prem[1] == 'Rs')
                                    				            {
                                    				                $premimum=($am)+$prem[0];
                                    				            }
                                    				            if($prem[1] == '%')
                                    				            {
                                    				                $premimum=($am*$prem[0])/100;
                                    				            }
                                    				            $dis_per=$ro->dis_per;
                                    				          
                                    				            //$dis=($c_amount*$dis_per)/100;
                                    				          
                                    				           if($premimum==NULL)
                                    				           {
                                    				           $premimum=0;
                                    				           }
                                    				            $c_amount=$c_amount+$premimum;
                                    				            $dis=($c_amount*$dis_per)/100;
                                    				           //$premimum
                                    				             $p_amount=$c_amount-$dis+$box_charges;
                                    				             $discount=$dis;
                                    				           
                                                				       
                                                				           

            							$table_data=array(
            							    'ro_main_id'=>$row['ro_main_id'],
            								'bill_id'=>$in_id,
            								'ro_id'=>$row['ro_id'],
            								'type_id'=>$row['type_id'],
            								'ro_session'=>$row['work_year'],
            								'insertion'=>$ro->insertion,
            								'pub_date'=>$row['dop'],
            								'paper'=>$row['paper_id'],
            								'heading'=>$heading_main,
            								'pack'=>$ro->pack,
					
            								'scheme'=>$ro->scheme,
            								'premimum'=>$values1['premimum'],
            								'premimum_val'=>$premimum,
            								'word_size'=>$ro->size_words,
            								'rate'=>$row['rate'],
            								'e_rate'=>$row['erate'],
            								'min_w'=>$ro->min_w,
            								'amount'=>$c_amount,
            								'box_charges'=>0,
            								'dis_per'=>$ro->dis_per,
            								'discount'=>$dis,
            								'net_amount'=>$p_amount,
            								'status'=>"Y",
            								'Ad_type'=>"Paid",
            										'size_type'=>$size_type,
            								);
            									               
                                    		      if($pcount1 > $Paid)
                                    				          
                                    				           { $table_data['amount']=0;
                                    				           $table_data['discount']=0;
                                    				               $table_data['net_amount']=0;
                                    				               $table_data['Ad_type']="Free";
                                    				           }
            						
            						
            							$this->db->insert('tbl_bill_details', $table_data);
            							$pcount1++;
            							
            						//	echo $this->db->last_query();
            							$word_size=split("X",$ro->size_words);
            						//	echo $ro->size_words."vv".var_dump($word_size)."</br>".var_dump($table_data);
            						//die;
            					
					}
            						    
            						}
}
            						$query=$this->db->query("select DISTINCT ro_id,insertion from tbl_bill_details where bill_id ='".$in_id."'" );
            						$ro_data=$query->result();
            						foreach($ro_data as $bd)
            						{
            					   $result=$this->db->select("*")->where(["id"=>$bd->ro_id])->get("tbl_book_ads")->row();
						            $this->db->where('id',$bd->ro_id);
                    	            $this->db->update("tbl_book_ads",["publish_day"=>($result->publish_day-$bd->insertion)]);
            						}
					$query=$this->db->query("select * from tbl_bill_details where bill_id ='".$in_id."'" );
	             // echo $this->db->last_query();
					$bill_data=$query->result();
					foreach($bill_data as $bd){
					    
					  
        					$query=$this->db->query("select * from tbl_ro_dop where ro_id ='".$bd->ro_id."' and work_year='".$bd->ro_session."' and paper_id='".$bd->paper."'" );
        				//	echo $this->db->last_query();
        					$rem=$query->result();
        					
        					
                                    $dates=explode(",",$bd->pub_date);
        					       // echo var_dump($dates);
        					        foreach($dates as $dt)
        					        {
                					          $dd=date_create($dt);
                					          $dt1=date_format($dd,"Y-m-d");
                					          $dt2=date_format($dd,"m/d/Y");
                					          foreach($rem as $re)
                					          {
                					                    $this->db->query("UPDATE `tbl_ro_dop` set `bill_dop`='$dt1', bill_status='Y',bill_number='$bill_no' where  `id`=$re->id  and (dop='".$dt1."' OR dop='".$dt2."')  ");
                					      //	echo $this->db->last_query();
                					          }
        					        
            					        }
        					    
        				
					
					
            					
            					
            			
            					
            		
					}} 
					$query=$this->db->query("delete from `tbl_bill_temp_details` where  emp_id='".$_SESSION['admin']['id']."' ");
		$query=$this->db->query("delete from `tbl_bill_temp` where  emp_id='".$_SESSION['admin']['id']."' ");

            						
            		$msg="5";
					echo $msg;
					return;	
			  
			           
			   }
			   else
			   {
			   
				$tbl_bill_temp=$this->db->where(['client_id'=>$this->input->post('client')])->get("tbl_bill_temp");
		
			
					$this->load->model("site_model");
					$res=$this->site_model->get_data("tbl_client",['id'=>$this->input->post('client')])[0];
					$client_name=$res['client_name'];
					
					//echo '<pre>'; var_dump($_POST); die;
					$days=$this->input->post('due_day')." days";
                    
                    
                    $dt=new DateTime($this->input->post('bill_date'));
                    $bill_date=$dt->format("Y-m-d");    
                    
                    
                    $due_date=date('Y-m-d',strtotime( $bill_date . ' +30 day'));
				//	$bill_no=bill_no_gen();
                                    
                    
					$values = array(
				// 		'bill_no'=>$bill_no,
				// 		'work_year'=> $_SESSION['work_year'],
				// 		'client_id'=> $this->input->post('client'),
				// 		'emp_id'=>$_SESSION['admin']['id'],
    //                     'bill_date'=> $bill_date,
						'amount'=> $this->input->post('amount'),
						'box_charges'=> $this->input->post('box_c'),
						'total'=> $this->input->post('total'),
						'dis_per'=> $this->input->post('dis_per'),
						'discount'=> $this->input->post('discount'),
						'art_work_charges'=> $this->input->post('art_work_charges'),
						'other_charges'=> $this->input->post('other_charges'),
						'net_amount'=> $this->input->post('net_amount'),
						'igst'=> $this->input->post('igst'),
						'cgst'=> $this->input->post('cgst'),
						'sgst'=> $this->input->post('sgst'),
						'due_date'=> $due_date,
						'Shared'=>'NO',
						'Shared_id'=>''
					);
					$query = $this->db->update('tbl_bill', $values,['id'=>$bill_id]);
				//	echo $this->db->last_query(); 
					$in_id=$bill_id;

					$result=$this->site_model->get_data("tbl_ledgers",['master_id'=>$this->input->post('client')])[0];
				//	echo "result id:".$result['ledger_id'];
					$ledger_id=$result['ledger_id'];
					if(empty($result['ledger_id'])){
						$values = array(
							'group_id'=>2,
							'master_id'=> $this->input->post('client'),
							'ledger_name'=> $client_name,
							'opening_balance'=>0,
							'editable'=>'no'
						);
						$ledger_id=$this->site_model->insert_data('tbl_ledgers', $values); 
					}

 $this->db->query("DELETE from tbl_vouchers where group_id= '2' and screen='Client Bill' and screen_id='$bill_id'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '9' and screen='Client Bill' and ledger_id='12' and screen_id='$bill_id'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '7' and screen='Client Bill' and ledger_id='9' and screen_id='$bill_id'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '15' and ledger_id='13' and screen='Client Bill' and screen_id='$bill_id'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '15' and ledger_id='14' and screen='Client Bill' and screen_id='$bill_id'");
            			$this->db->query("DELETE from tbl_vouchers where group_id= '15' and ledger_id='15' and screen='Client Bill' and screen_id='$bill_id'");
					$values = array(
						'group_id'=>2,
						'ledger_id'=> $ledger_id,
						'voucher_date'=> date("Y-m-d H:i:s"),
						'entry_type'=>'dr',
						'amount'=>$this->input->post('amount')-$this->input->post('discount')+$this->input->post('igst')+$this->input->post('sgst')+$this->input->post('cgst')+$this->input->post('box_c')+$this->input->post('at_w')+$this->input->post('other_c'),
						'narration'=>"Bill generated for ".$client_name."No: ".$bill_no,
						'voucher_no'=>1,
						'screen'=>"Client Bill",
						'screen_id'=>$in_id,
						'voucher_session'=>1
					);
					$this->site_model->insert_data('tbl_vouchers', $values); 
				//	echo $this->db->last_query(); 

					$values = array(
						'group_id'=>9,
						'ledger_id'=>12,
						'voucher_date'=> date("Y-m-d H:i:s"),
						'entry_type'=>'cr',
						'amount'=>$this->input->post('discount'),
						'narration'=>"Discount generated for ".$ledger_name." Bill No: ".$bill_no,
						'voucher_no'=>1,
						'screen'=>"Client Bill",
						'screen_id'=>$in_id,
						'voucher_session'=>1
					);
					$this->site_model->insert_data('tbl_vouchers', $values); 
				//	echo $this->db->last_query(); 

					$values = array(
						'group_id'=>7,
						'ledger_id'=>9,
						'voucher_date'=> date("Y-m-d H:i:s"),
						'entry_type'=>'cr',
						'amount'=>$this->input->post('total')+$this->input->post('box_c')+$this->input->post('at_w')+$this->input->post('other_c'),
						'narration'=>"Advertisement Income on Bill No: ".$bill_no,
						'voucher_no'=>1,
						'screen'=>"Client Bill",
						'screen_id'=>$in_id,
						'voucher_session'=>1
					);
					$this->site_model->insert_data('tbl_vouchers', $values); 
				//	echo $this->db->last_query(); 

					if($this->input->post('igst')){
					$values = array(
						'group_id'=>15,
						'ledger_id'=>13,
						'voucher_date'=> date("Y-m-d H:i:s"),
						'entry_type'=>'cr',
						'amount'=>$this->input->post('igst'),
						'narration'=>"IGST on Bill No: ".$bill_no,
						'voucher_no'=>1,
						'screen'=>"Client Bill",
						'screen_id'=>$in_id,
						'voucher_session'=>1
					);
					$this->site_model->insert_data('tbl_vouchers', $values); 
				//	echo $this->db->last_query(); 
					}

					if($this->input->post('cgst')){
					$values = array(
						'group_id'=>15,
						'ledger_id'=>14,
						'voucher_date'=> date("Y-m-d H:i:s"),
						'entry_type'=>'cr',
						'amount'=>$this->input->post('cgst'),
						'narration'=>"CGST on Bill No: ".$bill_no,
						'voucher_no'=>1,
						'screen'=>"Client Bill",
						'screen_id'=>$in_id,
						'voucher_session'=>1
					);
					$this->site_model->insert_data('tbl_vouchers', $values); 
				//	echo $this->db->last_query(); 
				}

				if($this->input->post('sgst')){
					$values = array(
						'group_id'=>15,
						'ledger_id'=>15,
						'voucher_date'=> date("Y-m-d H:i:s"),
						'entry_type'=>'cr',
						'amount'=>$this->input->post('sgst'),
						'narration'=>"UGST on Bill No: ".$bill_no,
						'voucher_no'=>1,
						'screen'=>"Client Bill",
						'screen_id'=>$in_id,
						'voucher_session'=>1
					);
					$this->site_model->insert_data('tbl_vouchers', $values); 
				
				}

					
					$result=$tbl_bill_temp->result();
					$bill_detail=array();
					$c=0;
                    $heading_main=0;
					$days=array();
				foreach($result as $ro){
					     $this->db->query("INSERT INTO `tbl_bill_edit`( `bill_id`, `ro_id`, `work_year`, `ro_no`, `client_id`, `emp_id`, `newspaper_id`, `type_id`, `cat_id`, `size_words`, `min_w`, `insertion`, `p_date`, `price`, `eprice`, `amount`, `scheme`, `pack`, `premimum`, `extra_price`, `add_on_amount`, `dis_per`, `discount`, `height`, `width`, `box_charges`, `payable_amount`, `ro_date`) values ('$in_id', '$ro->ro_id', '$ro->work_year', '$ro->ro_no', '$ro->client_id', '$ro->emp_id', '$ro->newspaper_id', '$ro->type_id', '$ro->cat_id', '$ro->size_words', '$ro->min_w', '$ro->insertion', '$ro->p_date', '$ro->price', '$ro->eprice', '$ro->amount', '$ro->scheme', '$ro->pack', '$ro->premimum', '$ro->extra_price', '$ro->add_on_amount', '$ro->dis_per', '$ro->discount', '$ro->height', '$ro->width', '$ro->box_charges', '$ro->payable_amount', '$ro->ro_date' ) ");    
                      
						$values1['box_charges']=$ro->box_charges;
						//$values1['p_amount']=($ro->amount+$ro->discount);
						$values1['status']="Y";
				
						/************* Enter into tbl_bill_details *********************************/
            					
            						  $tempdop=$ro->p_date;
                                    		    $tempro_id=$ro->ro_id;
                                    		    $Free=$ro->Free;
                                    		    $Paid=$ro->Paid;
                                    		  $size_type=$ro->size_type;
                                    		    $p_datetemp=explode(',',$tempdop);
                                    		    $pcount=1;
                                    		   
                                    		    foreach($p_datetemp as $dt)
                                    		    { 
                                    		        $ddtemp=date('Y-m-d',strtotime($dt));
                                    		        $query2=$this->db->query("select * from tbl_ro_dop where ro_id='$tempro_id' and dop='$ddtemp'");
                                    		       
                                    		        $result1=$query2->row();
                                    		        
                                    		        $dop_amount=floatval($result1->dop_amount);
                                    		       // $values1['insertion']=1;
                                    		        
                                                            	$c_amount=0;
                                    							$p_amount=0;
                                                                $discount=0;
                                    							 $extra_price=floatval($ro->eprice);
                                    				            $box_charges=floatval($ro->box_charges);
                                    				           
                                    				            if($ro->type_id==2|| $ro->type_id==3)
                                    				            {
                                    				            if($size_type=="F")
                                    				                {
                                    				                    	$c_amount+=floatval($ro->price)*(1);
                                    				                }
                                    				                else
                                    				                {
                                    				            	$word_size=split('X',$ro->size_words);
                                    				            	$len=$word_size[0];
                                    				            	$width=$word_size[1];
                                    				            	$c_amount+=floatval($ro->price)*floatval($len)*floatval($width)*(1);
                                    				                }
                                    				            }
                                    				            else
                                    				            {
                                    				               
                                    				            $c_amount+= floatval($ro->price)+(floatval($ro->size_words-$ro->min_w)*floatval($ro->eprice));
                                    				            
                                    				        	}
                                    				            $prem=explode(",",$ro->premimum);
                                                                $am=$c_amount;
                                    				           if($prem[1] == 'Rs')
                                    				            { 
                                    				                $premimum=($am)+$prem[0];
                                    				            }
                                    				            if($prem[1] == '%')
                                    				            {
                                    				                $premimum=($am*$prem[0])/100;
                                    				               
                                    				            }
                                                                
                                                                
                                                                if($premimum==NULL)
                                                                {
                                                                    $premimum=0;
                                                                }
                                    				            //premimum+=parseFloat(d.premimum);
                                    				            $dis_per=$ro->dis_per;
                                    				          
                                    				             $c_amount=$c_amount+$premimum;
                                    				            $dis=($c_amount*$dis_per)/100;
                                    				           //$premimum
                                    				             $p_amount=$c_amount-$dis+$box_charges;
                                    				             $discount=$dis;
                                    				         	      
                                    				             $heading_main=$ro->cat_id;
                                            						$values1=array();
                                            						$values1['ro_main_id']=$result1->id;
                                            						$values1['bill_id']=$in_id;
                                            						$values1['ro_id']=$ro->ro_id;
                                            						$values1['type_id']=$ro->type_id;
                                            						$values1['ro_session']=$ro->work_year;
                                            						$values1['insertion']=$ro->insertion;
                                            						$values1['pub_date']=$ddtemp;
                                            						$values1['paper']=$ro->newspaper_id;
                                            						$values1['heading']=$ro->cat_id;
                                            						$values1['pack']=$ro->pack;
                                            						$values1['scheme']=$ro->scheme;
                                            						$values1['premimum']=$ro->premimum;
                                            						$values1['premimum_val']=$premimum;
                                            						$values1['word_size']=$ro->size_words;
                                            						$values1['rate']=$ro->price;
                                            						$values1['e_rate']=$ro->eprice;
                                            						$values1['min_w']=$ro->min_w;
                                            						 $values1['amount']=$c_amount;
                                            						 $values1['box_charges']=$box_charges;
                                            						$values1['dis_per']=$ro->dis_per;
                                            					    $values1['discount']=$dis;
                                    				                 $values1['net_amount']=$p_amount;
                                    				                 $values1['status']="Y";
                                    				                
                                    				                  $values1['Ad_type']="Paid";
                                    				                  $values1['size_type']=$size_type;
                                    				                   
                                    				                   if($pcount > $Paid)
                                    				          
                                    				           {
                                    				               $values1['amount']=0;
                                    				               $values1['discount']=0;$values1['net_amount']=0;
                                    				               $values1['Ad_type']="Free";
                                    				           }
                                    		   
            						            $this->db->insert('tbl_bill_details', $values1);
            						            
            						            	$pcount++;
                                    		    }
            						//echo $this->db->last_query();
            /************* Enter into tbl_bill_details *********************************/
            						$resp=$this->site_model->get_data("tbl_bill_temp_details",['ro_id'=>$ro->ro_id]);
            						$pcount1=1;
            						if(!empty($resp))
            						{
            						foreach($resp as $row){
            						  
                                    		        $query=$this->db->query("select * from tbl_ro_dop where id='".$row['ro_main_id']."'");
                                    		       
                                    		        $result2=$query->row();
                                    		        $dop_amount2=floatval($result2->dop_amount);
            						                  $c_amount=0;
                                    							$p_amount=0;
                                                                $discount=0;
                                    							 $extra_price=floatval($row['erate']);
                                    				            $box_charges=floatval($ro->box_charges);
                                    				            if($row['type_id']==2 || $row['type_id']==3)
                                    				            {
                                    				                 if($size_type=="F")
                                    				                {
                                    				                    	$c_amount+=floatval($row['rate'])*(1);
                                    				                }
                                    				                else
                                    				                {
                                    				               $xx =$ro->size_words;
                                    				            	$word_size=split("X",$xx);
                                    				            	 $len=$word_size[0];
                                    				             	$width=$word_size[1];
                                    				             
                                    				            	$c_amount+=$row['rate']*floatval($len)*floatval($width)*(1);
                                    				                }
                                    				            
                                    				            }
                                    				            else
                                    				            {
                                    				            $c_amount+=floatval($row['rate'])+(floatval($ro->size_words-$ro->min_w)*floatval($row['erate']));
                                    				        	}
                                    				             $prem=explode(",",$ro->premimum);
                                                                 $am=$c_amount;
                                    				            if($prem[1] == 'Rs')
                                    				            {
                                    				                $premimum=($am)+$prem[0];
                                    				            }
                                    				            if($prem[1] == '%')
                                    				            {
                                    				                $premimum=($am*$prem[0])/100;
                                    				            }
                                    				            $dis_per=$ro->dis_per;
                                    				          
                                    				          //  $dis=($c_amount*$dis_per)/100;
                                    				          
                                    				           if($premimum==NULL)
                                    				           {
                                    				           $premimum=0;
                                    				           }
                                    				           
                                    				            $c_amount=$c_amount+$premimum;
                                    				            $dis=($c_amount*$dis_per)/100;
                                    				           //$premimum
                                    				             $p_amount=$c_amount-$dis+$box_charges;
                                    				             $discount=$dis;
                                                				       
                                                				           

            							$table_data=array(
            							    'ro_main_id'=>$row['ro_main_id'],
            								'bill_id'=>$in_id,
            								'ro_id'=>$row['ro_id'],
            								'type_id'=>$row['type_id'],
            								'ro_session'=>$row['work_year'],
            								'insertion'=>$ro->insertion,
            								'pub_date'=>$row['dop'],
            								'paper'=>$row['paper_id'],
            								'heading'=>$heading_main,
            								'pack'=>$ro->pack,
					
            								'scheme'=>$ro->scheme,
            								'premimum'=>$values1['premimum'],
            								'premimum_val'=>$premimum,
            								'word_size'=>$ro->size_words,
            								'rate'=>$row['rate'],
            								'e_rate'=>$row['erate'],
            								'min_w'=>$ro->min_w,
            								'amount'=>$c_amount,
            								'box_charges'=>0,
            								'dis_per'=>$ro->dis_per,
            								'discount'=>$dis,
            								'net_amount'=>$p_amount,
            								'status'=>"Y",
            								'Ad_type'=>"Paid",
            										'size_type'=>$size_type,
            								);
            									               
                                    		      if($pcount1 > $Paid)
                                    				          
                                    				           { $table_data['amount']=0;
                                    				           $table_data['discount']=0;
                                    				               $table_data['net_amount']=0;
                                    				               $table_data['Ad_type']="Free";
                                    				           }
            						
            						
            							$this->db->insert('tbl_bill_details', $table_data);
            							$pcount1++;
            							
            						//	echo $this->db->last_query();
            							$word_size=split("X",$ro->size_words);
            						//	echo $ro->size_words."vv".var_dump($word_size)."</br>".var_dump($table_data);
            						//die;
            					
					}
            						    
            						}
}
					$query=$this->db->query("delete from `tbl_bill_temp_details` where  emp_id='".$_SESSION['admin']['id']."' ");
		$query=$this->db->query("delete from `tbl_bill_temp` where  emp_id='".$_SESSION['admin']['id']."' ");

				
			   
				
				$query=$this->db->query("select DISTINCT ro_id,insertion from tbl_bill_details where bill_id ='".$in_id."'" );
            	$ro_data=$query->result();
            	foreach($ro_data as $bd)
            			{
            			   $result=$this->db->select("*")->where(["id"=>$bd->ro_id])->get("tbl_book_ads")->row();
				           $this->db->where('id',$bd->ro_id);
                          $this->db->update("tbl_book_ads",["publish_day"=>($result->publish_day-$bd->insertion)]);
            			}
				
					
					$query=$this->db->query("select * from tbl_bill_details where bill_id ='".$in_id."'" );
				//	echo $this->db->last_query();
	           
					$bill_data=$query->result();
					foreach($bill_data as $bd){	
					    
					   
                    		
        					$query=$this->db->query("select * from tbl_ro_dop where ro_id ='".$bd->ro_id."' and work_year='".$bd->ro_session."' and paper_id='".$bd->paper."'" );
        				
        				
        					$rem=$query->result();
        					
        					
                                    $dates=explode(",",$bd->pub_date);
        					     
        					        foreach($dates as $dt)
        					        {
                					          $dd=date_create($dt);
                					          $dt1=date_format($dd,"Y-m-d");
                					          $dt2=date_format($dd,"m/d/Y");
                					          foreach($rem as $re)
                					          {
                					                    $this->db->query("UPDATE `tbl_ro_dop` set `bill_dop`='$dt1', bill_status='Y',bill_number='$bill_no' where  `id`=$re->id  and (dop='".$dt1."' OR dop='".$dt2."')  ");
                		
                					          }
        					        
            					        }
        					  
        				
					
					}
			
			   
					$msg="5";
					echo $msg;
					return;					
				}
			}			
		}
	}
	
	public function bill_print($id)
	{
		$query = $this->db->query("SELECT tbl_bill.*, c.city, c.client_name,d.* FROM tbl_bill
		INNER JOIN tbl_client c ON c.id=tbl_bill.client_id INNER JOIN tbl_client_details d ON d.uid=tbl_bill.client_id  WHERE tbl_bill.id ='".$id."'" );
		$data['bill']= $query->row();
		
		$amount=number_format((float)$data['bill']->net_amount, 2, '.', '');
		$data['amount_words']=$this->get_words($amount); 
		
		$query = $this->db->get_where('tbl_bill_taxes', array('bill_id' => $id));
		$data['bill_taxes']= $query->result();
		
		$bill_detail = $this->db->query("SELECT tbl_bill_details.*, n.name as newspaper_name,n.short_name,ng.ng_name,ba.type_id,ba.color, p.position,s.scheme_name FROM tbl_bill_details
		INNER JOIN tbl_paper_city pc ON pc.id=tbl_bill_details.paper
		INNER JOIN tbl_newspapers n ON n.id=pc.paper_id
		INNER JOIN tbl_news_group ng ON ng.ng_id=n.g_id
		INNER JOIN tbl_book_ads ba ON ba.id=tbl_bill_details.ro_id
		LEFT JOIN tbl_position p ON p.id=tbl_bill_details.heading
		LEFT JOIN tbl_paper_scheme s ON s.id=tbl_bill_details.scheme
		WHERE tbl_bill_details.bill_id='".$id."'" );
		//LEFT JOIN tbl_premimum pr ON pr.id=tbl_bill_details.premium
        
		//echo $this->db->last_query(); die;
		
        $data['bill_details']=$bill_detail->result();
		//var_dump($data['bill_details']); die;
$posiSQL=$this->db->query("select * from tbl_position");
$posi=$posiSQL->result();
$position=[];
foreach($posi as $pp)
{
    $position[$pp->id]=$pp->position;
    
}
$catSQL=$this->db->query("select * from tbl_position");
$cati=$catSQL->result();
$cat=[];
foreach($cati as $cc)
{
    $cat[$cc->id]=$cc->cat_name;
    
}
$data['cat']=$cat;
$data['position']=$position;

//		$bill_detail = $this->db->query("SELECT tbl_bill_details.*, n.name as newspaper_name,n.short_name,ng.ng_name,ba.type_id,ba.color, p.position,s.scheme_name FROM tbl_bill_details
//		LEFT JOIN tbl_paper_city pc ON pc.id=tbl_bill_details.paper
//		LEFT JOIN tbl_newspapers n ON n.id=pc.paper_id
//		LEFT JOIN tbl_news_group ng ON ng.ng_id=n.g_id
//		LEFT JOIN tbl_book_ads ba ON ba.id=tbl_bill_details.ro_id
//		LEFT JOIN tbl_position p ON p.id=tbl_bill_details.heading
//		LEFT JOIN tbl_paper_scheme s ON s.id=tbl_bill_details.scheme
//		WHERE tbl_bill_details.bill_id='".$id."'" );
//		//LEFT JOIN tbl_premimum pr ON pr.id=tbl_bill_details.premium
//		
//		$data['ro_details']=$bill_detail->result();
		
		$this->load->view('admin/header');
		$this->load->view('admin/client_bill_print',$data);
		$this->load->view('admin/footer');
	}	
	
	public function bill_edit($id){
		$query = $this->db->query("SELECT tbl_bill.*, c.city, c.client_name FROM tbl_bill
		INNER JOIN tbl_client c ON c.id=tbl_bill.client_id WHERE tbl_bill.id ='".$id."'" );
		$data['bill']= $query->row();
		
		$amount=number_format((float)$data['bill']->net_amount, 2, '.', '');
		$data['amount_words']=$this->get_words($amount); 
		
		$query = $this->db->get_where('tbl_bill_taxes', array('bill_id' => $id));
		$data['bill_taxes']= $query->result();
		
		$bill_detail = $this->db->query("SELECT tbl_bill_details.*, n.name as newspaper_name,n.short_name,ng.ng_name,ba.type_id,ba.color, p.position,s.scheme_name,pr.premimum FRom tbl_bill_details
		INNER JOIN tbl_newspapers n ON n.id=tbl_bill_details.paper
		INNER JOIN tbl_news_group ng ON ng.ng_id=n.g_id
		INNER JOIN tbl_book_ads ba ON ba.id=tbl_bill_details.ro_id
		LEFT JOIN tbl_position p ON p.id=tbl_bill_details.heading
		LEFT JOIN tbl_paper_scheme s ON s.id=tbl_bill_details.scheme
		LEFT JOIN tbl_premimum pr ON pr.id=tbl_bill_details.premium
		WHERE tbl_bill_details.bill_id='".$id."' Group by tbl_bill_details.ro_id" );
		
		$bill_details= $bill_detail->result();
		$data['bill_details']=$bill_details;

		$bill_detail = $this->db->query("SELECT tbl_bill_details.*, n.name as newspaper_name,n.short_name,ng.ng_name,ba.type_id,ba.color, p.position,s.scheme_name,pr.premimum FRom tbl_bill_details
		INNER JOIN tbl_newspapers n ON n.id=tbl_bill_details.paper
		INNER JOIN tbl_news_group ng ON ng.ng_id=n.g_id
		INNER JOIN tbl_book_ads ba ON ba.id=tbl_bill_details.ro_id
		LEFT JOIN tbl_position p ON p.id=tbl_bill_details.heading
		LEFT JOIN tbl_paper_scheme s ON s.id=tbl_bill_details.scheme
		LEFT JOIN tbl_premimum pr ON pr.id=tbl_bill_details.premium
		WHERE tbl_bill_details.bill_id='".$id."'" );
		
		$data['ro_details']=$bill_detail->result();
		
			echo $this->db->last_query();
			die;
		$this->load->view('admin/header');
		$this->load->view('admin/client_bill_edit',$data);
		$this->load->view('admin/footer');
	}
	
	
	public function get_words($a)
	{	
		$q = strstr ( $a, '.' );
		$x=0;
		if(!empty($q))
		{
			$x=$q['1'].$q['2'];
		}
		$x=(int)$x;
		$y = floor($a);	
		
		//var_dump($y);
		
		//var_dump($x);
		
		
		$result=$this->convert_number_to_words($y)." Rupees";
		
		if(!empty($a=$this->convert_number_to_words($x)))
			$result=$result." AND ".$a." Paise";
		
		return $result;	
	}
	
	public function get_shared_parties()
	{
	    
	}
	public function convert_number_to_words($number) 
	{

		//$number = 168201.26;
   $no = round($number);
   $point = round($number - $no, 2) * 100;
   $hundred = null;
   $digits_1 = strlen($no);
   $i = 0;
   $str = array();
   $words = array('0' => '', '1' => 'One', '2' => 'Two',
    '3' => 'Three', '4' => 'Four', '5' => 'Five', '6' => 'Six',
    '7' => 'Seven', '8' => 'Eight', '9' => 'Nine',
    '10' => 'Ten', '11' => 'Eleven', '12' => 'Twelve',
    '13' => 'Thirteen', '14' => 'Fourteen',
    '15' => 'Fifteen', '16' => 'Sixteen', '17' => 'Seventeen',
    '18' => 'Eighteen', '19' =>'Nineteen', '20' => 'Twenty',
    '30' => 'Thirty', '40' => 'Forty', '50' => 'Fifty',
    '60' => 'Sixty', '70' => 'Seventy',
    '80' => 'Eighty', '90' => 'Ninety');
   $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
   while ($i < $digits_1) {
     $divider = ($i == 2) ? 10 : 100;
     $number = floor($no % $divider);
     $no = floor($no / $divider);
     $i += ($divider == 10) ? 1 : 2;
     if ($number) {
        $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
        $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
        $str [] = ($number < 21) ? $words[$number] .
            " " . $digits[$counter] . $plural . " " . $hundred
            :
            $words[floor($number / 10) * 10]
            . " " . $words[$number % 10] . " "
            . $digits[$counter] . $plural . " " . $hundred;
     } else $str[] = null;
  }
  $str = array_reverse($str);
  $result = implode('', $str);
  $points = ($point) ?
    "." . $words[$point / 10] . " " . 
          $words[$point = $point % 10] : '';
  return $result;		
}

	
	
	public function del_bill($bill_id)
	{
		//echo "hi";
		 $in_id=$bill_id;
		 echo $in_id;
	
	  if(!empty($in_id))
	  {
	      //query to add insertions back into the tbl_book_ads//
	      	$query=$this->db->query("select DISTINCT ro_id,insertion from tbl_bill_details where bill_id ='".$in_id."'" );
	      	echo $this->db->last_query();
            						$ro_data=$query->result();
            						foreach($ro_data as $bd)
            						{
            					   $result=$this->db->select("*")->where(["id"=>$bd->ro_id])->get("tbl_book_ads")->row();
            					   echo $this->db->last_query();
						            $this->db->where('id',$bd->ro_id);
                    	            $this->db->update("tbl_book_ads",["publish_day"=>($result->publish_day+$bd->insertion)]);
                    	            echo $this->db->last_query();
            						}
	      
	      	$query=$this->db->query("select * from tbl_bill where id ='".$in_id."'" );
	      	echo $this->db->last_query();
	      	$res=$query->result();
	      	echo var_dump($res);
	      	foreach ($res as $key => $value) {
	      		$bill_no=$value->bill_no;
	      	}
	      	
	      	$this->db->query("delete from tbl_vouchers where screen_id='".$bill_no."'");
	      	echo $this->db->last_query();
				// qurey to change status of ros//
	           $query=$this->db->query("select * from tbl_bill_details where bill_id ='".$in_id."'" );
	           echo $this->db->last_query();
				$bill_data=$query->result();
		    	foreach($bill_data as $bd)
		    	{	
		    	    $query=$this->db->query("select * from tbl_ro_dop where ro_id ='".$bd->ro_id."'  and paper_id='".$bd->paper."'" );
		    	    echo $this->db->last_query();
        	        	$rem=$query->result();
        					
        					
                                    $dates=explode(",",$bd->pub_date);
        					     
        					        foreach($dates as $dt)
        					        {
                					          $dd=date_create($dt);
                					          $dt1=date_format($dd,"Y-m-d");
                					          $dt2=date_format($dd,"m/d/Y");
                					          foreach($rem as $re)
                					          {
                					                    $this->db->query("UPDATE `tbl_ro_dop` set `bill_dop`='', bill_status='N',bill_number='0' where  `id`=$re->id  and (dop='".$dt1."' OR dop='".$dt2."')  ");
                		echo $this->db->last_query();
                					          }
        					        
            					        }
        		}
        		$this->db->query("delete from tbl_bill where id='".$bill_id."'");
        		echo $this->db->last_query();
        		$this->db->query("delete from tbl_bill_details where bill_id='".$bill_id."'");
        		echo $this->db->last_query();
	 
	  
	echo $this->session->flashdata('Deleted');
        redirect('admin/client_bill/') ;

        }
        else
        {echo $this->session->flashdata('Not Deleted');
        	redirect('admin/client_bill/');
        }
       
	}
	
}
?>